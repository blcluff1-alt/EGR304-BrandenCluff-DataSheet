#include "mcc_generated_files/system/system.h"
#include <stdint.h>
#include <stdio.h>

// Adjust to match your MCC ADC settings and supply/reference voltage
#define ADC_MAX_COUNTS     4095.0f   // 4095.0f for 12-bit ADC, 1023.0f for 10-bit ADC
#define VREF_VOLTS         5.0f      // Reference voltage in volts (e.g., 3.3V or 5.0V)

// Lux thresholds for the 4 brightness stages (tune to your sensor & environment)
#define LUX_DARK_MAX       50.0f     // < 50 lux     -> DARK
#define LUX_DIM_MAX        200.0f    // 50..199 lux   -> DIM
#define LUX_MODERATE_MAX   400.0f    // 100..399 lux -> MODERATE
                                     // >= 500 lux   -> BRIGHT

typedef enum {
    LIGHT_STAGE_DARK = 0,
    LIGHT_STAGE_DIM,
    LIGHT_STAGE_MODERATE,
    LIGHT_STAGE_BRIGHT
} LightStage_t;

// Redirects standard printf to UART1 (mapped to RC2 TX in MCC)
void putch(char data) {
    while (!UART1_IsTxReady()) {
        ; // Wait until UART1 TX is ready for the next byte
    }
    UART1_Write(data);
}

// Placeholder lux conversion: update this formula to match your light sensor circuit
float rawToLux(uint16_t rawAdc, float *voltageOut) {
    float voltage = ((float)rawAdc / ADC_MAX_COUNTS) * VREF_VOLTS;
    if (voltageOut != NULL) {
        *voltageOut = voltage;
    }

    // Example linear placeholder (replace with your sensor's datasheet/calibration curve)
    float lux = voltage * 100.0f;
    if (lux < 0.0f) {
        lux = 0.0f;
    }
    return lux;
}

LightStage_t classifyLightStage(float lux) {
    if (lux < LUX_DARK_MAX) {
        return LIGHT_STAGE_DARK;
    } else if (lux < LUX_DIM_MAX) {
        return LIGHT_STAGE_DIM;
    } else if (lux < LUX_MODERATE_MAX) {
        return LIGHT_STAGE_MODERATE;
    } else {
        return LIGHT_STAGE_BRIGHT;
    }
}

const char* lightStageToString(LightStage_t stage) {
    switch (stage) {
        case LIGHT_STAGE_DARK:     return "DARK";
        case LIGHT_STAGE_DIM:      return "DIM";
        case LIGHT_STAGE_MODERATE: return "MODERATE";
        case LIGHT_STAGE_BRIGHT:   return "BRIGHT";
        default:                   return "UNKNOWN";
    }
}

void main(void)
{
    // Initialize device drivers and peripherals configured in MCC
    SYSTEM_Initialize();

    // Test A: Verify LED on RA1 can turn on and turn back off cleanly
    LATAbits.LATA1 = 1;
    __delay_ms(500);
    LATAbits.LATA1 = 0;

    uint16_t lightValue = 0;

    while (1)
    {
        // 1. Read the raw ADC value using this project's MCC function and channel
        lightValue = ADC_ChannelSelectAndConvert(IO_RA0);

        // 2. Test B: Briefly discharge any trapped charge on RA2/C5 before reading
        LATAbits.LATA2 = 0;
        TRISAbits.TRISA2 = 0;
        __delay_us(50);
        TRISAbits.TRISA2 = 1;
        __delay_us(50);

        uint8_t buttonState = (PORTAbits.RA2 != 0) ? 1u : 0u;

        // 3. Control LED on RA1 based on button state
        if (buttonState == 1u) {
            LATAbits.LATA1 = 1; // Turn LED ON
        } else {
            LATAbits.LATA1 = 0; // Turn LED OFF
        }

        // 4. Convert raw ADC to voltage, lux, and brightness stage
        float voltage = 0.0f;
        float lux = rawToLux(lightValue, &voltage);
        LightStage_t stage = classifyLightStage(lux);
        const char *stageName = lightStageToString(stage);

        uint16_t mv = (uint16_t)(voltage * 1000.0f);
        uint32_t luxWhole = (uint32_t)lux;
        uint16_t luxFrac = (uint16_t)((lux - (float)luxWhole) * 100.0f);

        printf("ADC:%u (%u mV) | LUX:%lu.%02u | STAGE:%s | BTN:%u\r\n",
               lightValue, mv, (unsigned long)luxWhole, luxFrac, stageName, buttonState);

        __delay_ms(250);  // 250ms update rate for readable scrolling in PuTTY
    }
}